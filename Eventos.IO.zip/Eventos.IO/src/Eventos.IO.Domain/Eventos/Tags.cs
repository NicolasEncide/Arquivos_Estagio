﻿namespace Eventos.IO.Domain.Eventos
{
    public class Tags
    {
    }
}