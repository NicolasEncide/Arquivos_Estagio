﻿using Eventos.IO.Domain.Interfaces;

namespace Eventos.IO.Domain.Organizadores.Repository
{
    public interface IOrganizadorRepository : IRepository<Organizador>
    {
        
    }
}