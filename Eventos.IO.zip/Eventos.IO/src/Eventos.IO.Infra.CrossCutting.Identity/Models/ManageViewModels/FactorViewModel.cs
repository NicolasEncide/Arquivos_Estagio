﻿namespace Eventos.IO.Infra.CrossCutting.Identity.Models.ManageViewModels
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}
