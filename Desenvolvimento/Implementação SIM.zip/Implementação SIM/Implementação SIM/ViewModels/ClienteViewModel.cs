﻿
namespace Implementação_SIM.ViewModels
{
    public class ClienteViewModel
    {
        public string Nome { get; set; }
        public string Grupo { get; set; }
        public decimal Valor { get; set; }
        public DateTime DataVencimento { get; set; }
        public bool Recebido { get; set; }
        public DateTime? DataRecebimento { get; set; }
    }
}
