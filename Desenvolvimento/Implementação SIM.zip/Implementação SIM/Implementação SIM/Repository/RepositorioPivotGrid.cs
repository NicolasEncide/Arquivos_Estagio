﻿using System.Data;
using Dapper;
using Implementação_SIM.ViewModels;
using Npgsql;

namespace Implementação_SIM.Repository
{
    public class RepositorioPivotGrid
    {
        private readonly string _connectionString = "Host=localhost;Port=5432;Database=Teste;User Id=postgres;Password=nicolasN;";
        public async Task<List<ClienteViewModel>> ObterPorIntervaloDeData(DateTime datainicio, DateTime datafim )
        {
            IEnumerable<ClienteViewModel> resultado = null;
            var sql = @"select cl.""Nome"", co.""Grupo"", co.""Valor"", co.""DataVencimento"", r.""Recebido"", r.""DataRecebimento"" from ""Cliente"" cl inner join ""Conta"" co on cl.""Id"" = co.""ClienteId"" inner join ""Recebimento"" r on co.""Id"" = r.""ContaId"" where co.""DataVencimento"" >= @DataInicio and co.""DataVencimento"" <= @DataFim;";
            var param = new { DataInicio = datainicio, DataFim = datafim };
            
            try
            {
                using (var conexao = CriarConexao())
                {
                    resultado = await conexao.QueryAsync<ClienteViewModel>(sql, param);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao executar a chamada no banco: {ex.Message}");
            }
            
            return resultado.AsList();
        }
        private IDbConnection CriarConexao()
        {
            return new NpgsqlConnection(_connectionString);
        }
    }
}