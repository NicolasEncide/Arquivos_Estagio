﻿namespace Implementação_SIM
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DevExpress.XtraPivotGrid.DataSourceColumnBinding dataSourceColumnBinding1 = new DevExpress.XtraPivotGrid.DataSourceColumnBinding();
            DevExpress.XtraPivotGrid.DataSourceColumnBinding dataSourceColumnBinding2 = new DevExpress.XtraPivotGrid.DataSourceColumnBinding();
            DevExpress.XtraPivotGrid.DataSourceColumnBinding dataSourceColumnBinding3 = new DevExpress.XtraPivotGrid.DataSourceColumnBinding();
            DevExpress.XtraPivotGrid.DataSourceColumnBinding dataSourceColumnBinding4 = new DevExpress.XtraPivotGrid.DataSourceColumnBinding();
            DevExpress.XtraPivotGrid.DataSourceColumnBinding dataSourceColumnBinding5 = new DevExpress.XtraPivotGrid.DataSourceColumnBinding();
            DevExpress.XtraPivotGrid.DataSourceColumnBinding dataSourceColumnBinding6 = new DevExpress.XtraPivotGrid.DataSourceColumnBinding();
            buttonBuscar = new Button();
            dateTimePickerDtInicio = new DateTimePicker();
            dateTimePickerDtFim = new DateTimePicker();
            buttonLimpar = new Button();
            sqlDataSource1 = new DevExpress.DataAccess.Sql.SqlDataSource(components);
            label1 = new Label();
            label2 = new Label();
            pivotGridControl1 = new DevExpress.XtraPivotGrid.PivotGridControl();
            pivotGridField1 = new DevExpress.XtraPivotGrid.PivotGridField();
            pivotGridField2 = new DevExpress.XtraPivotGrid.PivotGridField();
            pivotGridField3 = new DevExpress.XtraPivotGrid.PivotGridField();
            pivotGridField4 = new DevExpress.XtraPivotGrid.PivotGridField();
            pivotGridField5 = new DevExpress.XtraPivotGrid.PivotGridField();
            pivotGridField6 = new DevExpress.XtraPivotGrid.PivotGridField();
            ((System.ComponentModel.ISupportInitialize)pivotGridControl1).BeginInit();
            SuspendLayout();
            // 
            // buttonBuscar
            // 
            buttonBuscar.BackColor = SystemColors.InactiveCaption;
            buttonBuscar.ForeColor = SystemColors.ActiveCaptionText;
            buttonBuscar.Location = new Point(47, 377);
            buttonBuscar.Name = "buttonBuscar";
            buttonBuscar.Size = new Size(111, 48);
            buttonBuscar.TabIndex = 1;
            buttonBuscar.Text = "Buscar";
            buttonBuscar.UseVisualStyleBackColor = false;
            buttonBuscar.Click += buttonBuscar_Click_1;
            // 
            // dateTimePickerDtInicio
            // 
            dateTimePickerDtInicio.Location = new Point(256, 12);
            dateTimePickerDtInicio.Name = "dateTimePickerDtInicio";
            dateTimePickerDtInicio.Size = new Size(310, 27);
            dateTimePickerDtInicio.TabIndex = 3;
            // 
            // dateTimePickerDtFim
            // 
            dateTimePickerDtFim.Location = new Point(709, 12);
            dateTimePickerDtFim.Name = "dateTimePickerDtFim";
            dateTimePickerDtFim.Size = new Size(312, 27);
            dateTimePickerDtFim.TabIndex = 4;
            // 
            // buttonLimpar
            // 
            buttonLimpar.BackColor = SystemColors.InactiveCaption;
            buttonLimpar.ForeColor = SystemColors.ActiveCaptionText;
            buttonLimpar.Location = new Point(180, 377);
            buttonLimpar.Name = "buttonLimpar";
            buttonLimpar.Size = new Size(111, 48);
            buttonLimpar.TabIndex = 5;
            buttonLimpar.Text = "Limpar";
            buttonLimpar.UseVisualStyleBackColor = false;
            buttonLimpar.Click += buttonLimpar_Click_1;
            // 
            // sqlDataSource1
            // 
            sqlDataSource1.Name = "sqlDataSource1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(163, 17);
            label1.Name = "label1";
            label1.Size = new Size(87, 20);
            label1.TabIndex = 9;
            label1.Text = "Data Inicial:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(624, 17);
            label2.Name = "label2";
            label2.Size = new Size(79, 20);
            label2.TabIndex = 10;
            label2.Text = "Data Final:";
            // 
            // pivotGridControl1
            // 
            pivotGridControl1.DesignTimeDataObjectType = typeof(ViewModels.ClienteViewModel);
            pivotGridControl1.Fields.AddRange(new DevExpress.XtraPivotGrid.PivotGridField[] { pivotGridField1, pivotGridField2, pivotGridField3, pivotGridField4, pivotGridField5, pivotGridField6 });
            pivotGridControl1.Location = new Point(47, 45);
            pivotGridControl1.Name = "pivotGridControl1";
            pivotGridControl1.OptionsData.DataProcessingEngine = DevExpress.XtraPivotGrid.PivotDataProcessingEngine.Optimized;
            pivotGridControl1.OptionsView.ShowFilterHeaders = false;
            pivotGridControl1.Size = new Size(1235, 313);
            pivotGridControl1.TabIndex = 11;
            // 
            // pivotGridField1
            // 
            pivotGridField1.Area = DevExpress.XtraPivotGrid.PivotArea.RowArea;
            pivotGridField1.AreaIndex = 0;
            pivotGridField1.Caption = "Nome";
            dataSourceColumnBinding1.ColumnName = "Nome";
            pivotGridField1.DataBinding = dataSourceColumnBinding1;
            pivotGridField1.Name = "pivotGridField1";
            pivotGridField1.Width = 150;
            // 
            // pivotGridField2
            // 
            pivotGridField2.Area = DevExpress.XtraPivotGrid.PivotArea.RowArea;
            pivotGridField2.AreaIndex = 1;
            pivotGridField2.Caption = "Grupo";
            dataSourceColumnBinding2.ColumnName = "Grupo";
            pivotGridField2.DataBinding = dataSourceColumnBinding2;
            pivotGridField2.Name = "pivotGridField2";
            pivotGridField2.Width = 150;
            // 
            // pivotGridField3
            // 
            pivotGridField3.Area = DevExpress.XtraPivotGrid.PivotArea.DataArea;
            pivotGridField3.AreaIndex = 0;
            pivotGridField3.Caption = "Valor";
            dataSourceColumnBinding3.ColumnName = "Valor";
            pivotGridField3.DataBinding = dataSourceColumnBinding3;
            pivotGridField3.Name = "pivotGridField3";
            pivotGridField3.Width = 150;
            // 
            // pivotGridField4
            // 
            pivotGridField4.Area = DevExpress.XtraPivotGrid.PivotArea.ColumnArea;
            pivotGridField4.AreaIndex = 0;
            pivotGridField4.Caption = "Data de Vencimento";
            dataSourceColumnBinding4.ColumnName = "DataVencimento";
            pivotGridField4.DataBinding = dataSourceColumnBinding4;
            pivotGridField4.Name = "pivotGridField4";
            pivotGridField4.Width = 150;
            // 
            // pivotGridField5
            // 
            pivotGridField5.Area = DevExpress.XtraPivotGrid.PivotArea.RowArea;
            pivotGridField5.AreaIndex = 2;
            pivotGridField5.Caption = "Recebido?";
            dataSourceColumnBinding5.ColumnName = "Recebido";
            pivotGridField5.DataBinding = dataSourceColumnBinding5;
            pivotGridField5.Name = "pivotGridField5";
            pivotGridField5.Width = 150;
            // 
            // pivotGridField6
            // 
            pivotGridField6.Area = DevExpress.XtraPivotGrid.PivotArea.RowArea;
            pivotGridField6.AreaIndex = 3;
            pivotGridField6.Caption = "Data de Recebimento";
            dataSourceColumnBinding6.ColumnName = "DataRecebimento";
            pivotGridField6.DataBinding = dataSourceColumnBinding6;
            pivotGridField6.EmptyValueText = "N/R";
            pivotGridField6.Name = "pivotGridField6";
            pivotGridField6.Width = 150;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1315, 450);
            Controls.Add(pivotGridControl1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonLimpar);
            Controls.Add(dateTimePickerDtFim);
            Controls.Add(dateTimePickerDtInicio);
            Controls.Add(buttonBuscar);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pivotGridControl1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonBuscar;
        private DateTimePicker dateTimePickerDtInicio;
        private DateTimePicker dateTimePickerDtFim;
        private Button buttonLimpar;
        private DevExpress.DataAccess.Sql.SqlDataSource sqlDataSource1;
        private Label label1;
        private Label label2;
        private DevExpress.XtraPivotGrid.PivotGridControl pivotGridControl1;
        private DevExpress.XtraPivotGrid.PivotGridField pivotGridField1;
        private DevExpress.XtraPivotGrid.PivotGridField pivotGridField2;
        private DevExpress.XtraPivotGrid.PivotGridField pivotGridField3;
        private DevExpress.XtraPivotGrid.PivotGridField pivotGridField4;
        private DevExpress.XtraPivotGrid.PivotGridField pivotGridField5;
        private DevExpress.XtraPivotGrid.PivotGridField pivotGridField6;
    }
}
