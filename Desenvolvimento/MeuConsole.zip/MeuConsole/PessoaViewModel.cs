﻿namespace MeuConsole
{
    public class PessoaViewModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public double Altura { get; set; }
        public string? Informacao { get; set; }
    }
}