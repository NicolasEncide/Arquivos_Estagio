﻿namespace MeuConsole
{
    public static class ChamadaAPI
    {
        public static async Task BuscarCEP(string cep)
        {
            string url = $"https://viacep.com.br/ws/{cep}/json/";

            // Usando HttpClient para fazer a chamada
            using var client = new HttpClient();

            try
            {
                // Fazendo a requisição GET
                HttpResponseMessage response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode(); // Garante que a resposta foi bem-sucedida (HTTP 2xx)

                // Lendo o conteúdo como string
                string conteudo = await response.Content.ReadAsStringAsync();

                // Mostrando o resultado no console
                Console.WriteLine("Dados do CEP retornados pela API:");
                Console.WriteLine(conteudo);
            }
            catch (Exception ex)
            {
                // Tratamento de erros
                Console.WriteLine($"Erro ao buscar o CEP: {ex.Message}");
            }
        }
    }
}
