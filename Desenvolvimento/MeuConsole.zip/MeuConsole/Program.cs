﻿using Npgsql;
using Dapper;
using MeuConsole;

class Program
{
    static async Task Main(string[] args)
    {
        #region Exercício chamada em uma API
        /*
        Console.WriteLine("Digite o CEP que deseja buscar:");
        string cep = Console.ReadLine();

        await ChamadaAPI.BuscarCEP(cep);
        */
        #endregion
        
        #region Exercícios Banco de Dados

        //string connectionString = "Host=localhost;Port=5433;Username=postgres;Password=nicolasN;Database=postgres";

        //using var connection = new NpgsqlConnection(connectionString);
        #region Exemplo 1
        /*
        string sql = "select nome, altura from pessoa";

        var resultados = connection.Query<dynamic>(sql);

        Console.WriteLine("Resultados encontrados:");
        Console.WriteLine();

        foreach (var resultado in resultados)
        {
            Console.WriteLine($"Nome: {resultado.nome}, Altura: {resultado.altura};");
        }
        */
        #endregion
        #region Exemplo 2
        /*
        string sql = "select nome from pessoa";

        var resultados = connection.Query<string>(sql);

        Console.WriteLine("Resultados encontrados:");
        Console.WriteLine();

        foreach (var resultado in resultados)
        {
            Console.WriteLine($"Nome: {resultado};");
        }
        */
        #endregion
        #region Exemplo 3
        /*
        string sql = "select altura from pessoa where id = @id";

        var param = new { id = 7 };

        var resultados = connection.Query<double>(sql, param);

        Console.WriteLine("Resultados encontrados:");
        Console.WriteLine();

        foreach (var resultado in resultados)
        {
            Console.WriteLine($"Altura da pessoa com Id 7: {resultado};");
        }
        */
        #endregion
        #region Exemplo 4
        /*
        string sql = "select * from pessoa where id >= @id1 and id <= @id2";

        var param = new { id1 = 5, id2 = 10 };

        var resultados = connection.Query<PessoaViewModel>(sql, param);

        Console.WriteLine("Resultados encontrados:");
        Console.WriteLine();

        foreach (var resultado in resultados)
        {
            var informacao = resultado.Informacao ?? "Sem informação";
            Console.WriteLine($"Id: {resultado.Id}, Nome: {resultado.Nome}, Altura: {resultado.Altura.ToString("F2")}, Informação: {informacao};");
        }
        */
        #endregion

        #endregion
    }
}