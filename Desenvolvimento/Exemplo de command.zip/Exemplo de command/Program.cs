﻿public interface ICommand
{
    void Executar();
    void Desfazer();
}
public class Lampada
{
    public void Ligado()
    {
        Console.WriteLine("Lâmpada ligada");
    }
    public void Desligado()
    {
        Console.WriteLine("Lâmpada desligada");
    }
}

public class LigarLampadaCommand : ICommand
{
    private Lampada _lampada;
    public LigarLampadaCommand(Lampada lampada)
    {
        _lampada = lampada;
    }
    public void Executar()
    {
        _lampada.Ligado();
    }
    public void Desfazer()
    {
        _lampada.Desligado();
    }
}
public class DesligarLampadaCommand : ICommand
{
    private Lampada _lampada;
    public DesligarLampadaCommand(Lampada lampada)
    {
        _lampada = lampada;
    }
    public void Executar()
    {
        _lampada.Desligado();
    }
    public void Desfazer()
    {
        _lampada.Ligado();
    }
}
public class ControleRemoto
{
    private ICommand _command;
    public void SetCommand(ICommand command)
    {
        _command = command;
    }
    public void BotãoExecutarCommand()
    {
        _command.Executar();
    }
    public void BotãoDesfazerCommand()
    {
        _command.Desfazer();
    }
}
class Program
{
    static void Main(string[] args)
    {
        Lampada lampada = new Lampada();

        ICommand ligar = new LigarLampadaCommand(lampada);
        ICommand desligar = new DesligarLampadaCommand(lampada);

        ControleRemoto controleRemoto = new ControleRemoto();

        controleRemoto.SetCommand(ligar);
        controleRemoto.BotãoExecutarCommand();
        controleRemoto.BotãoDesfazerCommand();
        controleRemoto.SetCommand(desligar);
        controleRemoto.BotãoDesfazerCommand();
        controleRemoto.BotãoExecutarCommand();
    }
}