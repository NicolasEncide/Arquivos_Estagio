﻿namespace TesteQRCode
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraPrinting.BarCode.Code128Generator code128Generator1 = new DevExpress.XtraPrinting.BarCode.Code128Generator();
            barCodeControl1 = new DevExpress.XtraEditors.BarCodeControl();
            SuspendLayout();
            // 
            // barCodeControl1
            // 
            barCodeControl1.Location = new Point(296, 173);
            barCodeControl1.Name = "barCodeControl1";
            barCodeControl1.Padding = new Padding(10, 2, 10, 0);
            barCodeControl1.Size = new Size(156, 36);
            barCodeControl1.Symbology = code128Generator1;
            barCodeControl1.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(barCodeControl1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private DevExpress.XtraEditors.BarCodeControl barCodeControl1;
    }
}
