using ZXing;

namespace TesteQRCode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            string link = "";
            GenerateQRCode(link);

        }
        private void GenerateQRCode(string text)
        {
            BarcodeWriter<Bitmap> writer = new BarcodeWriter<Bitmap>
            {
                Format = BarcodeFormat.QR_CODE,
                Options = new ZXing.Common.EncodingOptions
                {
                    Width = 200,
                    Height = 200,
                    Margin = 1
                }
            };

            Bitmap qrCodeImage = writer.Write(text);

            PictureBox pictureBox = new PictureBox
            {
                Image = qrCodeImage,
                SizeMode = PictureBoxSizeMode.AutoSize,
                Location = new System.Drawing.Point(50, 50)
            };

            this.Controls.Add(pictureBox);

        }

    }
}
