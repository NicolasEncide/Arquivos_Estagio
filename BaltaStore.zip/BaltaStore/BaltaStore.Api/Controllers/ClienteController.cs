﻿using BaltaStore.Domain.LojaContexto.CommandHandlers;
using BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Inputs;
using BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Outputs;
using BaltaStore.Domain.LojaContexto.Entidades;
using BaltaStore.Domain.LojaContexto.Queries;
using BaltaStore.Domain.LojaContexto.Repositorios;
using BaltaStore.Shared.Commands;
using Microsoft.AspNetCore.Mvc;

namespace BaltaStore.Api.Controllers
{
    public class ClienteController : Controller
    {
        private readonly IClienteRepositorio _repositorio;
        private readonly ClienteCommandHandler _handler;
        public ClienteController(IClienteRepositorio repositorio, ClienteCommandHandler handler)
        {
            _repositorio = repositorio;
            _handler = handler;
        }
        [HttpGet]
        [Route("clientes")]
        [ResponseCache(Duration = 15)]
        public List<ListaClientesResult> GetClientes()
        {
            return _repositorio.GetClientes();
        }
        [HttpGet]
        [Route("clientes/{Id}")]
        public ActionResult<GetClienteResult> GetCliente([FromRoute] Guid id)
        {
            Console.WriteLine($"Recebendo solicitação para cliente com ID {id}");
            var cliente = _repositorio.GetCliente(id);

            if (cliente == null)
            {
                Console.WriteLine($"Cliente com ID {id} não encontrado.");
                return NotFound();
            }

            Console.WriteLine($"Cliente com ID {id} encontrado: {cliente.Nome}");
            return Ok(cliente);
        }
        [HttpGet]
        [Route("clientes/{Id}/pedidos")]
        public List<ListaPedidosClienteResult> GetPedidos(Guid id)
        {
            return _repositorio.GetPedidos(id);
        }
        [HttpPost]
        [Route("clientes")]
        public ICommandResult Post([FromBody]CriarClienteCommand command)
        {
            var result = (CriarClienteCommandResult)_handler.Handle(command);
            return result;
        }
        [HttpPut]
        [Route("clientes/{Id}")]
        public Cliente Put([FromBody]CriarClienteCommand command)
        {
            return null;
        }
        [HttpDelete]
        [Route("clientes/{Id}")]
        public string Delete()
        {
            return null;
        }
    }
}
