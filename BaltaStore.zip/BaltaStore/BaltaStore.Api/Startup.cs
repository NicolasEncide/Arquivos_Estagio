﻿using BaltaStore.Domain.LojaContexto.CommandHandlers;
using BaltaStore.Domain.LojaContexto.Repositorios;
using BaltaStore.Domain.LojaContexto.Servicos;
using BaltaStore.Infra.LojaContexto.DataContexts;
using BaltaStore.Infra.LojaContexto.Repositorios;
using BaltaStore.Infra.LojaContexto.Servicos;
using BaltaStore.Shared;
using Microsoft.OpenApi.Models;

namespace BaltaStore.Api
{
    public class Startup
    {
        public static IConfiguration Configuration { get; set; }
        public void ConfigureServices(IServiceCollection services)
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");

            Configuration = builder.Build();

            services.AddMvc();
            services.AddResponseCompression();
            services.AddControllersWithViews(options =>
            {
                options.EnableEndpointRouting = false;
            });
            services.AddScoped<BaltaDataContext, BaltaDataContext>();
            services.AddTransient<IClienteRepositorio, ClienteRepositorio>();
            services.AddTransient<IEmailServico, EmailServico>();
            services.AddTransient<ClienteCommandHandler, ClienteCommandHandler>();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "BaltaStore", Version = "v1" });

                c.MapType<Guid>(() => new OpenApiSchema
                {
                    Type = "string",
                    Format = "uuid"
                });
            });
            services.AddElmahIo(options =>
            {
                options.ApiKey = "b1d1aa9be8154a9db579bfe39a8cda2c";
                options.LogId = new Guid("746d9c95-1134-49ae-8a13-202c64941e83");
            });
            Settings.ConnectionString = $"{Configuration["connectionString"]}";
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseElmahIo();
            app.UseMvc();
            app.UseResponseCompression();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "BaltaStore - V1");
            });
        }
    }
}
