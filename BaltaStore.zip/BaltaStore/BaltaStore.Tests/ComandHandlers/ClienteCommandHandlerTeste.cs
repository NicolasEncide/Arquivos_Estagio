﻿
using BaltaStore.Domain.LojaContexto.CommandHandlers;
using BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Inputs;
using BaltaStore.Tests.Fakes_Mocks;

namespace BaltaStore.Tests.ComandHandlers
{
    [TestClass]
    public class ClienteCommandHandlerTeste
    {
        [TestMethod]
        public void DeveRegistrarClienteQuandoCommandValido()
        {
            var command = new CriarClienteCommand();
            command.PrimeiroNome = "Nicolas";
            command.UltimoNome = "Sousa";
            command.Email = "niencide@gmail.com";
            command.Telefone = "17997589393";
            command.Documento = "46084627846";

            Assert.AreEqual(true, command.Valid);

            var handler = new ClienteCommandHandler(new FakeClienteRepositorio(), new FakeEmailServico());
            var result = handler.Handle(command);

            Assert.AreNotEqual(null, result);
            Assert.AreEqual(true, handler.Valid);
        }
    }
}
