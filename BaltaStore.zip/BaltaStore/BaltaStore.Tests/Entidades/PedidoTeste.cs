﻿
using BaltaStore.Domain.LojaContexto.Entidades;
using BaltaStore.Domain.LojaContexto.Enumeradores;
using BaltaStore.Domain.LojaContexto.ObjetosDeValor;

namespace BaltaStore.Tests.Entidades
{
    [TestClass]
    public class PedidoTeste
    {
        private Produto _mouse { get; set; }
        private Produto _teclado { get; set; }
        private Produto _cadeira { get; set; }
        private Produto _impressora { get; set; }
        private Cliente _cliente { get; set; }
        private Pedido _pedido { get; set; }
        public PedidoTeste()
        {
            var nome = new Nome("Nicolas", "Sousa");
            var documento = new Documento("46084627846");
            var email = new Email("niencide@gmail.com");
            _cliente = new Cliente(nome, documento, email, "17997589393");
            _pedido = new Pedido(_cliente);
            _mouse = new Produto("Mouse Gamer", "Mouse Top", "mouse.png", 99M, 10M);
            _teclado = new Produto("Teclado Gamer", "Teclado Top", "teclado.png", 150M, 10M);
            _cadeira = new Produto("Cadeira Gamer", "Cadeira Top", "cadeira.png", 500M, 10M);
            _impressora = new Produto("Impressora Gamer", "Impressora Top", "impressora.png", 200M, 10M);
        }
        // Criar pedido quando válido
        [TestMethod]
        public void DeveCriarPedidoQuandoforValido()
        {
            Assert.AreEqual(true, _pedido.Valid);
        }
        // Ao criar um pedido, status deve ser Criado
        [TestMethod]
        public void StatusDeveSerCriadoQuandoPedidoCriado()
        {
            Assert.AreEqual(EStatusPedido.Criado, _pedido.Status);
        }
        // Ao adicionar um novo item, a quantidade de itens deve mudar
        [TestMethod]
        public void DeveRetornarDoisQuandoDoisItensValidosAdicionados()
        {
            _pedido.AdicionarItem(_mouse, 2);
            _pedido.AdicionarItem(_teclado, 2);
            Assert.AreEqual(2, _pedido.Itens.Count);
        }

        // Ao adicionar um novo item, deve subtrair a quantidade do produto
        [TestMethod]
        public void DeveRetornarCincoQuandoCompradoCinco()
        {
            _pedido.AdicionarItem(_mouse, 5);
            Assert.AreEqual(5, _mouse.QuantidadeEstoque);
        }

        // Ao confirmar pedido, deve gerar um número
        [TestMethod]
        public void DeveRetornarUmNumeroQuandoPedidoConfirmado()
        {
            _pedido.CriarPedido();
            Assert.AreNotEqual("", _pedido.Numero);
        }

        // Ao pagar o pedido, status deve ser Pago
        [TestMethod]
        public void StatusDeveSerPagoQuandoPedidoPago()
        {
            _pedido.PagarPedido();
            Assert.AreEqual(EStatusPedido.Pago, _pedido.Status);
        }

        // Dado mais 10 produtos, deve haver mais 2 entregas
        [TestMethod]
        public void DeveRetornarDoisEntregasQuandoCompradoDezProdutos()
        {
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.AdicionarItem(_mouse, 1);
            _pedido.EnviarPedido();
            Assert.AreEqual(2, _pedido.Entregas.Count);
        }

        // Ao cancelar o pedido, o status deve ser Cancelado
        [TestMethod]
        public void StatusDeveSerCanceladoQuandoPedidoCancelado()
        {
            _pedido.CancelarPedido();
            Assert.AreEqual(EStatusPedido.Cancelado, _pedido.Status);
        }

        // Ao cancelar o pedido, as entregas devem ser canceladas
        [TestMethod]
        public void DeveCancelarEntregasQuandoPedidoCancelado()
        {
            _pedido.AdicionarItem(_impressora, 10M);
            _pedido.EnviarPedido();
            _pedido.CancelarPedido();
            foreach (var x in _pedido.Entregas)
            {
                Assert.AreEqual(EStatusEntrega.Cancelado, x.Status);
            }
        }
    }
}
