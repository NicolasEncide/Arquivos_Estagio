﻿
using BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Inputs;

namespace BaltaStore.Tests.Commands
{
    [TestClass]
    public class CriarClienteCommandTeste
    {
        [TestMethod]
        public void DeveValidarQuandoCommandForValido()
        {
            var command = new CriarClienteCommand();
            command.PrimeiroNome = "Nicolas";
            command.UltimoNome = "Sousa";
            command.Email = "niencide@gmail.com";
            command.Telefone = "17997589393";
            command.Documento = "46084627846";

            Assert.AreEqual(true, command.Valid);
        }
    }
}
