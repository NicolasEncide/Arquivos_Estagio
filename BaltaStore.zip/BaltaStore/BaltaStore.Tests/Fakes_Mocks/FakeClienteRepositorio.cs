﻿
using BaltaStore.Domain.LojaContexto.Entidades;
using BaltaStore.Domain.LojaContexto.Queries;
using BaltaStore.Domain.LojaContexto.Repositorios;

namespace BaltaStore.Tests.Fakes_Mocks
{
    public class FakeClienteRepositorio : IClienteRepositorio
    {
        public bool ChecarDocumento(string documento)
        {
            return false;
        }

        public bool ChecarEmail(string email)
        {
            return false;
        }

        public ContagemPedidosClienteResult ContagemPedidosClienteResult(string documento)
        {
            throw new NotImplementedException();
        }

        public GetClienteResult GetCliente(Guid id)
        {
            throw new NotImplementedException();
        }

        public List<ListaClientesResult> GetClientes()
        {
            throw new NotImplementedException();
        }

        public List<ListaPedidosClienteResult> GetPedidos(Guid id)
        {
            throw new NotImplementedException();
        }

        public void Salvar(Cliente cliente)
        {
            
        }
    }
}
