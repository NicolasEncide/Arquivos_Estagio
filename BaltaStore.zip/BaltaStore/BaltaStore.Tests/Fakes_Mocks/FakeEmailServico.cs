﻿
using BaltaStore.Domain.LojaContexto.Servicos;

namespace BaltaStore.Tests.Fakes_Mocks
{
    public class FakeEmailServico : IEmailServico
    {
        public void Mandar(string para, string de, string assunto, string corpo)
        {
            
        }
    }
}
