
using BaltaStore.Domain.LojaContexto.ObjetosDeValor;

namespace BaltaStore.Tests.ObjetosDeValor
{
    [TestClass]
    public class DocumentoTeste
    {
        private Documento _documentoValido { get; set; }
        private Documento _documentoInvalido { get; set; }
        public DocumentoTeste()
        {
            _documentoValido = new Documento("46084627846");
            _documentoInvalido = new Documento("12345678910");
        }
        [TestMethod]
        public void DeveRetornarUmaNotificacaoQuandoDocumentoInvalido()
        {
            Assert.AreEqual(false, _documentoInvalido.Valid);
            Assert.AreEqual(1, _documentoInvalido.Notifications.Count);
        }
        [TestMethod]
        public void NaoDeveRetornarUmaNotificacaoQuandoDocumentoValido()
        {
            Assert.AreEqual(true, _documentoValido.Valid);
            Assert.AreEqual(0, _documentoValido.Notifications.Count);
        }
    }
}