﻿
using BaltaStore.Domain.LojaContexto.ObjetosDeValor;

namespace BaltaStore.Tests.ObjetosDeValor
{
    [TestClass]
    public class NomeTeste
    {
        [TestMethod]
        public void DeveRetornarUmaNotificacaoQuandoNomeInvalido()
        {
            var nome = new Nome("N", "Sousa");
            Assert.AreEqual(false, nome.Valid);
            Assert.AreEqual(1, nome.Notifications.Count);
        }
    }
}
