﻿
namespace BaltaStore.Shared
{
    public static class Settings
    {
        public static string ConnectionString = "Host=localhost;Port=5432;Username=postgres;Password=nicolasN;Database=BaltaStore;";
    }
}
