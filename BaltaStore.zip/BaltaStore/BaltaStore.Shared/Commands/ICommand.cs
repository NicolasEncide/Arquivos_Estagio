﻿
namespace BaltaStore.Shared.Commands
{
    public interface ICommand
    {
      public bool Validar();
    }
}
