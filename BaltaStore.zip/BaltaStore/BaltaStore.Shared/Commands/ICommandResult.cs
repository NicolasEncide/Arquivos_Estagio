﻿
namespace BaltaStore.Shared.Commands
{
    public interface ICommandResult
    {
        bool Sucesso { get; set; }
        string Mensagem { get; set; }
        object Dado { get; set; }
    }
}
