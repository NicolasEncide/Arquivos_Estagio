﻿
using BaltaStore.Domain.LojaContexto.Entidades;
using BaltaStore.Domain.LojaContexto.Queries;

namespace BaltaStore.Domain.LojaContexto.Repositorios
{
    public interface IClienteRepositorio
    {
        public bool ChecarDocumento(string documento);
        public bool ChecarEmail(string email);
        public void Salvar(Cliente cliente);
        public ContagemPedidosClienteResult ContagemPedidosClienteResult(string documento);
        public List<ListaClientesResult> GetClientes();
        public GetClienteResult GetCliente(Guid id);
        public List<ListaPedidosClienteResult> GetPedidos(Guid id);
    }
}
