﻿
using FluentValidator;
using FluentValidator.Validation;

namespace BaltaStore.Domain.LojaContexto.ObjetosDeValor
{
    public class Nome : Notifiable
    {
        public Nome(string primeiroNome, string ultimoNome)
        {
            PrimeiroNome = primeiroNome;
            UltimoNome = ultimoNome;

            // Validação usando validationcontract
            AddNotifications(new ValidationContract()
                .Requires()
                .HasMinLen(PrimeiroNome, 3, "PrimeiroNome", "O nome deve conter no mínimo 3 caracteres")
                .HasMaxLen(PrimeiroNome, 40, "PrimeiroNome", "O nome deve conter no máximo 40 caracteres")
                .HasMinLen(UltimoNome, 3, "PrimeiroNome", "O sobrenome deve conter no mínimo 3 caracteres")
                .HasMaxLen(UltimoNome, 40, "PrimeiroNome", "O sobrenome deve conter no máximo 40 caracteres")
                );
        }
        public string PrimeiroNome { get; private set; }
        public string UltimoNome { get; private set; }


        public override string ToString()
        {
            return $"{PrimeiroNome} {UltimoNome}";
        }
    }
}
