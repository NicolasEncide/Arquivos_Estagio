﻿
using BaltaStore.Shared.Commands;
using FluentValidator;
using FluentValidator.Validation;

namespace BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Inputs
{
    public class CriarClienteCommand : Notifiable, ICommand
    {
        public string PrimeiroNome { get; set; }
        public string UltimoNome { get; set; }
        public string Documento { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }

        public bool Validar()
        {
            AddNotifications(new ValidationContract()
                .HasMinLen(PrimeiroNome, 3, "PrimeiroNome", "O nome deve conter no mínimo 3 caracteres")
                .HasMaxLen(PrimeiroNome, 40, "PrimeiroNome", "O nome deve conter no máximo 40 caracteres")
                .HasMinLen(UltimoNome, 3, "PrimeiroNome", "O sobrenome deve conter no mínimo 3 caracteres")
                .HasMaxLen(UltimoNome, 40, "PrimeiroNome", "O sobrenome deve conter no máximo 40 caracteres")
                .IsEmail(Email, "Email", "O Email é inválido")
                .HasLen(Documento, 11, "Documento", "O CPF é inválido")
                );
            return Valid;
        }
    }
}