﻿
using BaltaStore.Domain.LojaContexto.Enumeradores;
using BaltaStore.Shared.Commands;
using FluentValidator;

namespace BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Inputs
{
    public class AdicionarEnderecoCommand : Notifiable, ICommand
    {
        public Guid Id { get; set; }
        public string Rua { get; set; }
        public string Numero { get; set; }
        public string Complemento { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public string Pais { get; set; }
        public string Cep { get; set; }
        public EEnderecoTipo Tipo { get; set; }

        public bool Validar()
        {
            return Valid;
        }
    }
}
