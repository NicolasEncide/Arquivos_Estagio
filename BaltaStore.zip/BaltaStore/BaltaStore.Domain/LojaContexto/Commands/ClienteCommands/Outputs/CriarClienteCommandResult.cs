﻿
using BaltaStore.Shared.Commands;

namespace BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Outputs
{
    public class CriarClienteCommandResult : ICommandResult
    {
        public CriarClienteCommandResult(bool sucesso, string mensagem, object dado)
        {
            Sucesso = sucesso;
            Mensagem = mensagem;
            Dado = dado;
        }

        public bool Sucesso { get; set; }
        public string Mensagem { get; set; }
        public object Dado { get; set; }
    }
}