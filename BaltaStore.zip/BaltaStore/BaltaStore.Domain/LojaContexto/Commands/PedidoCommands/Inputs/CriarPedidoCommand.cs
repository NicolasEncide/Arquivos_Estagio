﻿
using BaltaStore.Shared.Commands;
using FluentValidator;
using FluentValidator.Validation;

namespace BaltaStore.Domain.LojaContexto.Commands.PedidoCommands.Inputs
{
    public class CriarPedidoCommand : Notifiable, ICommand
    {
        public CriarPedidoCommand()
        {
            Itens = new List<ItemDoPedidoCommand>();
        }
        public Guid Cliente { get; set; }
        public IList<ItemDoPedidoCommand> Itens { get; set; }

        public bool Validar()
        {
            AddNotifications(new ValidationContract()
                .Requires()
                .HasLen(Cliente.ToString(), 36, "Cliente", "Identificador do cliente inválido")
                .IsGreaterThan(Itens.Count(), 0, "Itens", "Nenhum item do pedido foi encontrado")
                );
            return Valid;
        }
    }


    public class ItemDoPedidoCommand : Notifiable, ICommand
    {
        public Guid Produto { get; set; }
        public decimal Quantidade { get; set; }

        public bool Validar()
        {
           throw new NotImplementedException();
        }
    }
}
