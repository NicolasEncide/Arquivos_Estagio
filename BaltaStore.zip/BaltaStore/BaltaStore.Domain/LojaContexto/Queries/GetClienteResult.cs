﻿namespace BaltaStore.Domain.LojaContexto.Queries
{
    public class GetClienteResult
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
        public string Documento { get; set; }
        public string Email { get; set; }
    }
}
