﻿
namespace BaltaStore.Domain.LojaContexto.Queries
{
    public class ContagemPedidosClienteResult
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
        public string Documento { get; set; }
        public int Pedidos { get; set; }
    }
}
