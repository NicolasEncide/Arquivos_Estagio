﻿
namespace BaltaStore.Domain.LojaContexto.Servicos
{
    public interface IEmailServico
    {
        public void Mandar(string para, string de, string assunto, string corpo);
    }
}
