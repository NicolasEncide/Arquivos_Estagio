/*
using System;

namespace BaltaStore.Domain.StoreContext
{
    public class Pessoa : IPessoa
    {
        public string Nome { get; set; } ="";
        public DateTime DataDeAniversario { get; set; }

        public void AoRegistrar()
        {
            throw new NotImplementedException();
        }
    }
   // A interface é um contrato, quando uma classe a herda, ela obrigatoriamente precisa ter as mesmas propriedades, métodos e eventos da interface.
    public interface IPessoa 
    {
        string Nome { get; set; }
        DateTime DataDeAniversario { get; set; }

        void AoRegistrar();
    }
    public class Cliente : Pessoa
    {   // uma classe pode ser pública(public), privada(private) ou protegida(protected)
        // uma classe pública pública pode ser acessada de qualquer lugar do projeto
        // uma classe protegida só pode ser acessada internamente e pelas classes que herdam ela
        // uma classe privada só pode ser acessada dentro dela mesma
        public decimal Salario { get; set; }
        public void AoRegistrar()
        {

        }
        // o override retorna um string que representa um objeto, nesse caso, o Cliente retornará como a propriedade Nome
        public override string ToString()
        {
            return Nome;
        }
    }
         // A classe Funcionario herda da classe Pessoa, logo ela terá as mesmas propriedades, métodos e eventos da mesma
    public class Funcionario : Pessoa
    {
        public decimal Salario { get; set; }
        public void AoRegistrar()
        {
            
        }
    }
    public class Vendedor : Pessoa
    {
        public decimal Salario { get; set; }
        public void AoRegistrar()
        {
            
        }
    }
}
*/
// PARA VALIDAR ESSE CÓDIGO, RETIRAR O /* E */ NO COMEÇO E NO FINAL