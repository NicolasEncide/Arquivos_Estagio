﻿
namespace BaltaStore.Domain.LojaContexto.Enumeradores
{
    public enum EStatusEntrega
    {
        Esperando = 1,
        Enviado = 2,
        Cancelado = 3,
        Finalizado = 4
    }
}
