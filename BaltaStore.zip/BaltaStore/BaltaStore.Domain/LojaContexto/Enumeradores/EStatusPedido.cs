﻿
namespace BaltaStore.Domain.LojaContexto.Enumeradores
{
    public enum EStatusPedido
    {
        Criado = 1,
        Pago = 2,
        Enviado = 3,
        Cancelado = 4
    }
}
