﻿
namespace BaltaStore.Domain.LojaContexto.Enumeradores
{
    public enum EEnderecoTipo
    {
        Envio = 1,
        Cobrança = 2
    }
}
