using BaltaStore.Shared.Entidades;

namespace BaltaStore.Domain.LojaContexto.Entidades
{
    public class ItemDoPedido : Entidade
    {
        public ItemDoPedido(Produto produto, decimal quantidade)
        {
            Produto = produto;
            Quantidade = quantidade;
            Preco = Produto.Preco;

            if (produto.QuantidadeEstoque < quantidade)
                AddNotification("Quantidade", "Quantidade fora de estoque");

            Produto.SubtrairDoEstoque(quantidade);
        }
        public Produto Produto { get; private set; }
        public decimal Quantidade { get; private set; }
        public decimal Preco { get; private set; }
    }
}
