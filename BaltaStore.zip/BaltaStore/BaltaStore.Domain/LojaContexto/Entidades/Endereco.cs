﻿using BaltaStore.Domain.LojaContexto.Enumeradores;
using BaltaStore.Shared.Entidades;

namespace BaltaStore.Domain.LojaContexto.Entidades
{
    public class Endereco : Entidade
    {
        public Endereco(string rua, string numero, string complemento, string bairro, string cidade, string estado, string pais, string cep, EEnderecoTipo tipo)
        {
            Rua = rua;
            Numero = numero;
            Complemento = complemento;
            Bairro = bairro;
            Cidade = cidade;
            Estado = estado;
            Pais = pais;
            Cep = cep;
            Tipo = tipo;
        }
        public string Rua { get; private set; }
        public string Numero { get; private set; }
        public string Complemento { get; private set; }
        public string Bairro { get; private set; }
        public string Cidade { get; private set; }
        public string Estado { get; private set; }
        public string Pais { get; private set; }
        public string Cep { get; private set; }
        public EEnderecoTipo Tipo { get; private set; }

        public override string ToString()
        {
            return $"{Rua}, {Numero} - {Cidade}/{Estado}";
        }
    }
}
