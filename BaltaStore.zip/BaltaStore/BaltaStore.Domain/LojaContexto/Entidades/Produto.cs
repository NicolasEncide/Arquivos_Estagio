using BaltaStore.Shared.Entidades;

namespace BaltaStore.Domain.LojaContexto.Entidades
{
    public class Produto : Entidade
    {
        public Produto(string titulo, string descricao, string imagem, decimal preco, decimal quantidadeEstoque)
        {
            Titulo = titulo;
            Descricao = descricao;
            Imagem = imagem;
            Preco = preco;
            QuantidadeEstoque = quantidadeEstoque;
        }
        public string Titulo { get; private set; }
        public string Descricao { get; private set; }
        public string Imagem { get; private set; }
        public decimal Preco { get; private set; }
        public decimal QuantidadeEstoque { get; private set; }

        public override string ToString()
        {
            return Titulo;
        }

        public void SubtrairDoEstoque(decimal quantidade)
        {
            QuantidadeEstoque -= quantidade;
        }
    }
}
