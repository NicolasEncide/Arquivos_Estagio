using BaltaStore.Domain.LojaContexto.Enumeradores;
using BaltaStore.Shared.Entidades;

namespace BaltaStore.Domain.LojaContexto.Entidades
{
    public class Pedido : Entidade
    {
        private readonly IList<Entrega> _entregas;
        private readonly IList<ItemDoPedido> _itens;
        public Pedido(Cliente cliente)
        {
            Cliente = cliente;
            Numero = Guid.NewGuid().ToString().Replace("-", "").Substring(0,8).ToUpper();
            DataCriacao = DateTime.Now;
            Status = EStatusPedido.Criado;
            _itens = new List<ItemDoPedido>();
            _entregas = new List<Entrega>();
        }
        public virtual Cliente Cliente { get; private set; }
        public string Numero { get; private set; }
        public DateTime DataCriacao { get; private set; }
        public EStatusPedido Status { get; private set; }
        public virtual IReadOnlyCollection<ItemDoPedido> Itens { get { return _itens.ToArray(); } }
        // public virtual IReadOnlyCollection<ItemDoPedido> Itens { get { return _itens.AsReadOnly(); } }
        public virtual IReadOnlyCollection<Entrega> Entregas { get { return _entregas.ToArray(); } }


        // Adicionar ao pedido e validar itens
        public void AdicionarItem(Produto produto, decimal quantidade)
        {
            if (quantidade > produto.QuantidadeEstoque)
                AddNotification("ItemDoPedido", $"Produto {produto.Titulo} n�o tem {quantidade} itens em estoque");

            var item = new ItemDoPedido(produto, quantidade);
            _itens.Add(item);
           
        }

        // Criar um pedido
        public void CriarPedido()
        {
            // gerar n�mero do pedido
            Numero = Guid.NewGuid().ToString().Replace("-", "").Substring(0, 8).ToUpper();
            // Validar
            if (_itens.Count == 0)
                AddNotification("Pedido", "Este pedido n�o possui itens");
        }

        // Pagar o pedido
        public void PagarPedido()
        {
           Status = EStatusPedido.Pago;
        }

        // Enviar o pedido
        public void EnviarPedido()
        {
            var entregas = new List<Entrega>();
            var count = 1;

            // Quebra as entregas
            foreach (var item in _itens)
            {
                if (count == 5) 
                {
                   entregas.Add(new Entrega(DateTime.Now.AddDays(5)));
                   count = 1;
                }
               count++;
            }

            // Envia todas as entregas
            entregas.ForEach(x => x.Enviar());

            // Adiciona a entrega ao pedido
            entregas.ForEach(x => _entregas.Add(x));
        }

        // Cancelar o pedido
        public void CancelarPedido()
        {
            Status = EStatusPedido.Cancelado;
            _entregas.ToList().ForEach(x => x.Cancelar());
        }

    }
}
