using BaltaStore.Domain.LojaContexto.Enumeradores;
using BaltaStore.Shared.Entidades;

namespace BaltaStore.Domain.LojaContexto.Entidades
{
    public class Entrega : Entidade
    {
        public Entrega(DateTime dataEntregaEstimada)
        {
            DataCriacao = DateTime.Now;
            DataEntregaEstimada = dataEntregaEstimada;
            Status = EStatusEntrega.Esperando;
        }
        public DateTime DataCriacao { get; private set; }
        public DateTime DataEntregaEstimada { get; private set; }
        public EStatusEntrega Status { get; private set; }

        public void Enviar()
        {
            // Se a data de entrega estimada for no passado, n�o entregar
            Status = EStatusEntrega.Enviado;
        }
        public void Cancelar()
        {
            // se o status ja estiver entregue, n�o pode cancelar
            Status = EStatusEntrega.Cancelado;
        }
    }
}
