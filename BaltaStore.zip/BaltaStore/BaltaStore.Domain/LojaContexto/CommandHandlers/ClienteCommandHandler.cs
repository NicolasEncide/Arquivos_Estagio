﻿
using BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Inputs;
using BaltaStore.Domain.LojaContexto.Commands.ClienteCommands.Outputs;
using BaltaStore.Domain.LojaContexto.Entidades;
using BaltaStore.Domain.LojaContexto.ObjetosDeValor;
using BaltaStore.Domain.LojaContexto.Repositorios;
using BaltaStore.Domain.LojaContexto.Servicos;
using BaltaStore.Shared.Commands;
using FluentValidator;

namespace BaltaStore.Domain.LojaContexto.CommandHandlers
{
    public class ClienteCommandHandler : Notifiable, ICommandHandler<CriarClienteCommand>, ICommandHandler<AdicionarEnderecoCommand>
    {
        private readonly IClienteRepositorio _repositorio;
        private readonly IEmailServico _emailServico;

        public ClienteCommandHandler(IClienteRepositorio repositorio, IEmailServico emailServico)
        {
            _repositorio = repositorio;
            _emailServico = emailServico;
        }
        public ICommandResult Handle(CriarClienteCommand command)
        {
            // Verificar se o CPF já existe no banco
            if (_repositorio.ChecarDocumento(command.Documento))
                AddNotification("Documento", "Este CPF já está em uso"); 

            // Veriificar se o Email já existe no banco
            if (_repositorio.ChecarEmail(command.Email))
                AddNotification("Email", "Este Email já está em uso");

            // Criar os VOs
            var nome = new Nome(command.PrimeiroNome, command.UltimoNome);
            var documento = new Documento(command.Documento);
            var email = new Email(command.Email);

            // Criar a Entidade
            var cliente = new Cliente(nome, documento, email, command.Telefone);

            // Validar entidades e VOs
            AddNotifications(nome.Notifications);
            AddNotifications(documento.Notifications);
            AddNotifications(email.Notifications);
            AddNotifications(cliente.Notifications);
            if (Invalid)
                return new CriarClienteCommandResult(false, "Por favor, corrija os campos abaixo", Notifications);

            // Persistir o cliente
            _repositorio.Salvar(cliente);

            // Enviar email de boas vindas
            _emailServico.Mandar(email.Endereco, "niencide@gmail.com", "Boas-Vindas", "Bem vindo ao BaltaStore!");

            // Retornar o resultado para a tela
            return new CriarClienteCommandResult(true, "Bem vindo ao BaltaStore!", new
            {
                Id = cliente.Id,
                Nome = nome.ToString(),
                Email = email.Endereco
            });
        }

        public ICommandResult Handle(AdicionarEnderecoCommand command)
        {
            throw new NotImplementedException();
        }
    }
}
