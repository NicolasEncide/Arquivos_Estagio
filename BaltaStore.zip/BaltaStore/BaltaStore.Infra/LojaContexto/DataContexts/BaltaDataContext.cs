﻿
using BaltaStore.Shared;
using Npgsql;
using System.Data;

namespace BaltaStore.Infra.LojaContexto.DataContexts
{
    public class BaltaDataContext : IDisposable
    {
        public BaltaDataContext()
        {
            Connection = new NpgsqlConnection(Settings.ConnectionString);
            Connection.Open();
        }
        public NpgsqlConnection Connection { get; set; }
        public void Dispose()
        {
            if (Connection.State != ConnectionState.Closed)
            Connection.Close();
        }
    }
}
