﻿
using BaltaStore.Domain.LojaContexto.Servicos;

namespace BaltaStore.Infra.LojaContexto.Servicos
{
    public class EmailServico : IEmailServico
    {
        public void Mandar(string para, string de, string assunto, string corpo)
        {

        }
    }
}
