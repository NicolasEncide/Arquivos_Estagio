﻿using BaltaStore.Domain.LojaContexto.Entidades;
using BaltaStore.Domain.LojaContexto.Queries;
using BaltaStore.Domain.LojaContexto.Repositorios;
using BaltaStore.Infra.LojaContexto.DataContexts;
using Dapper;
using System.Data;

namespace BaltaStore.Infra.LojaContexto.Repositorios
{
    public class ClienteRepositorio : IClienteRepositorio
    {
        private readonly BaltaDataContext _context;

        public ClienteRepositorio(BaltaDataContext context)
        {
            _context = context;
        }

        public bool ChecarDocumento(string documento)
        {
            return _context.Connection.Query<bool>
                ("SELECT spchecardocumento(@p_Documento)", new { p_Documento = documento }).FirstOrDefault();
        }

        public bool ChecarEmail(string email)
        {
            return _context.Connection.Query<bool>
                ("SELECT spchecaremail(@p_Email)", new { p_Email = email }).FirstOrDefault();
        }

        public ContagemPedidosClienteResult ContagemPedidosClienteResult(string documento)
        {
            return _context.Connection.Query<ContagemPedidosClienteResult>
                ("SELECT spgetclientescompedido(@p_Documento)", new { p_Documento = documento }).FirstOrDefault();
        }

        public List<ListaClientesResult> GetClientes()
        {
            return _context.Connection.Query<ListaClientesResult>
                ("SELECT Id, PrimeiroNome || ' ' || UltimoNome AS Nome, Documento, Email FROM Cliente;", new {}).ToList();
        }

        public GetClienteResult GetCliente(Guid id)
        {
            Console.WriteLine($"Buscando cliente com ID {id}");
            var result = _context.Connection.Query<GetClienteResult>(
                "SELECT Id, PrimeiroNome || ' ' || UltimoNome AS Nome, Documento, Email FROM Cliente WHERE Id = @Id",
                new { Id = id }
            ).FirstOrDefault();

            if (result == null)
                Console.WriteLine($"Nenhum cliente encontrado com ID {id}");
            else
                Console.WriteLine($"Cliente encontrado: {result.Nome}");

            return result;
        }

        public List<ListaPedidosClienteResult> GetPedidos(Guid id)
        {
            return _context.Connection.Query<ListaPedidosClienteResult>
                ("", new { id = id }).ToList();
        }
    

        public void Salvar(Cliente cliente)
        {
            _context.Connection.Execute(
            "CALL spcriarcliente(@p_Id, @p_PrimeiroNome, @p_UltimoNome, @p_Documento, @p_Email, @p_Telefone)",
            new
            {
                p_Id = cliente.Id,
                p_PrimeiroNome = cliente.Nome.PrimeiroNome,
                p_UltimoNome = cliente.Nome.UltimoNome,
                p_Documento = cliente.Documento.Numero,
                p_Email = cliente.Email.Endereco,
                p_Telefone = cliente.Telefone,
            });
            foreach (var endereco in cliente.Enderecos)
            {
                _context.Connection.Execute(
                    "CALL spcriarendereco(@p_Id, @p_ClienteId, @p_Numero, @p_Complemento, @p_Bairro, @p_Cidade, @p_Estado, @p_Pais, @p_Cep, @p_Tipo)",
                    new
                    {
                        p_Id = endereco.Id,
                        p_ClienteId = cliente.Id,
                        p_Numero = endereco.Numero,
                        p_Complemento = endereco.Complemento,
                        p_Bairro = endereco.Bairro,
                        p_Cidade = endereco.Cidade,
                        p_Estado = endereco.Estado,
                        p_Pais = endereco.Pais,
                        p_Cep = endereco.Cep,
                        p_Tipo = endereco.Tipo,
                    });
            }
        }
    }
}
