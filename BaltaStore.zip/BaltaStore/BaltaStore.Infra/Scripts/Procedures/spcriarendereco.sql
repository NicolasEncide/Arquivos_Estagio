CREATE OR REPLACE PROCEDURE spcriarendereco(
    p_Id UUID,
    p_ClienteId UUID,
    p_Numero VARCHAR(10),
    p_Complemento VARCHAR(40),
    p_Bairro VARCHAR(60),
    p_Cidade VARCHAR(60),
    p_Estado CHAR(2),
    p_Pais CHAR(2),
    p_Cep CHAR(8),
    p_Tipo INT
) AS $$
BEGIN
    INSERT INTO Endereco (
        Id,
        ClienteId,
        Numero,
        Complemento,
        Bairro,
        Cidade,
        Estado,
        Pais,
        Cep,
        Tipo
    ) VALUES (
        p_Id,
        p_ClienteId,
        p_Numero,
        p_Complemento,
        p_Bairro,
        p_Cidade,
        p_Estado,
        p_Pais,
        p_Cep,
        p_Tipo
    );
END;
$$ LANGUAGE plpgsql;