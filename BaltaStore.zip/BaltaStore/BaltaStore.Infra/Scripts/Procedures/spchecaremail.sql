CREATE OR REPLACE FUNCTION spchecaremail(
    p_Email VARCHAR(160)
) RETURNS BOOLEAN AS $$
DECLARE
    v_Result BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT Id
        FROM Cliente
        WHERE Email = p_Email
    ) INTO v_Result;

    RETURN v_Result;
END;
$$ LANGUAGE plpgsql;