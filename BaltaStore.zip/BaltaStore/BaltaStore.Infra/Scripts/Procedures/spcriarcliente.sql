DROP PROCEDURE IF EXISTS spcriarcliente(uuid, text, text, text, text, text);
CREATE OR REPLACE PROCEDURE spcriarcliente(
    p_Id UUID,
    p_PrimeiroNome VARCHAR(40),
    p_UltimoNome VARCHAR(40),
    p_Documento VARCHAR(11),
    p_Email VARCHAR(160),
    p_Telefone VARCHAR(13)
) AS $$
BEGIN
    INSERT INTO Cliente (
        Id,
        PrimeiroNome,
        UltimoNome,
        Documento,
        Email,
        Telefone
    ) VALUES (
        p_Id,
        p_PrimeiroNome,
        p_UltimoNome,
        p_Documento,
        p_Email,
        p_Telefone
    );
END;
$$ LANGUAGE plpgsql;