CREATE OR REPLACE FUNCTION spgetclientes()
RETURNS TABLE (
    Id UUID,
    Nome VARCHAR,
    Documento VARCHAR(11),
    Email VARCHAR(160)
) AS $$
BEGIN
    RETURN QUERY
    SELECT Id, PrimeiroNome || ' ' || UltimoNome AS Nome, Documento, Email
    FROM Cliente;
END;
$$ LANGUAGE plpgsql;