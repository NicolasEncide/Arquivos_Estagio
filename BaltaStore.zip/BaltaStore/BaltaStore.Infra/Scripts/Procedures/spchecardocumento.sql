CREATE OR REPLACE FUNCTION spchecardocumento(
    p_Documento VARCHAR(11)
) RETURNS BOOLEAN AS $$
DECLARE
    v_Result BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT Id
        FROM Cliente
        WHERE Documento = p_Documento
    ) INTO v_Result;

    RETURN v_Result;
END;
$$ LANGUAGE plpgsql;