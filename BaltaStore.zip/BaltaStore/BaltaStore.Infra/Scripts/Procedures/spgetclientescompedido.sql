CREATE OR REPLACE FUNCTION spgetclientecompedido(
    p_Documento VARCHAR(11)
) RETURNS TABLE (
    Id UUID,
    Nome VARCHAR,
    Documento VARCHAR(11)
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.Id,
        CONCAT(c.PrimeiroNome, ' ', c.UltimoNome) AS Nome,
        c.Documento
    FROM 
        Cliente c
    INNER JOIN 
        Pedido p ON p.ClienteId = c.Id
    WHERE 
        c.Documento = p_Documento;
END;
$$ LANGUAGE plpgsql;